<?php require('header.php'); ?>
<div class="container">
    <h2>Kontak</h2>
    <div class="box">
        <p>Nama : Flandylan Rui</p>
        <p>Nim : 312110604</p>
        <p>Kelas : TI.21.A.1</p>
        <p>Matkul : Pemograman Web 2</p>
        <p>Email : apaajahprojectds@gmail.com</p>
        <p>No. Telp : 0232032032</p>
    </div>
</div>
<?php require('footer.php'); ?>
